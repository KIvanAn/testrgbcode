<?php

/**
 * Plugin Name: Custom users plugin
 * Version: 1.0
 * Author: Ivan
 */

require_once 'functions.php';
require_once 'views/table.php';

add_shortcode('custom_table', 'custom_table');

function custom_table() {
	if ( current_user_can('administrator') ) {
		echo '<div id="table">';
		table();
		echo '</div>';
		return;
	}

	return 'This content can see only administrator!!!';
}
