<?php

add_action('wp_head', 'add_custom_table_css', 18);

function add_custom_table_css()
{
	?>
	<link rel="stylesheet" href='/wp-content/plugins/custom-users-plugin/css/style.css' media='all' />
	<?php
}

add_action('wp_footer', 'add_custom_table_script', 18);

function add_custom_table_script() {
	$url = admin_url('admin-ajax.php');
	$nonce = wp_create_nonce('myajax-nonce');
	?>
	<script>
        const myajax = {
            url: '<?php echo $url; ?>',
            nonce: '<?php echo $nonce; ?>'
        }
	</script>
	<script src='/wp-content/plugins/custom-users-plugin/js/script.js'></script>
	<?php
}

add_action('wp_ajax_new_page', 'new_page_handler');

function new_page_handler() {
	check_ajax_referer( 'myajax-nonce', 'nonce_code' );

	require_once 'views/table.php';
	$page = $_POST['page'];
	$role = $_POST['role'];
	$orderby = $_POST['orderby'];
	$order = $_POST['order'];

	table($page, $role, $orderby, $order);

	die;
}

