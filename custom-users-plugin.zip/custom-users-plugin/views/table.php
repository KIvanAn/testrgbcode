<?php

function table($page = 1, $role = '', $orderby = 'user_login', $order = 'asc') {

$current_page = $page;
$users_per_page = 10;

$args = array(
	'role' => $role,
	'number' => $users_per_page,
	'paged' => $current_page,
    'orderby' => $orderby,
    'order' => $order
);

$users = new WP_User_Query( $args );
$users_roles = ['All roles', 'Administrator', 'Author', 'Editor', 'Subscriber'];
$roles = '';

$total_users = $users->get_total();
$num_pages = ceil($total_users / $users_per_page);

	if ( ! empty( $users->get_results() ) ) {
		foreach ( $users->get_results() as $user ) {
			$result .= '<tr>
		    <td>' . $user->user_login . '</td>
		    <td>' . $user->display_name . '</td>
		    <td>' . $user->user_email . '</td>
		    <td>' . $user->roles[0] . '</td>
		    <td>' . $user->user_registered . '</td>
		  </tr>';
		}
	} else {
		echo 'No users found.';
	}

    foreach ($users_roles as $users_role) {
        if ($users_role === $role) {
            $roles .= '<option selected>'. $users_role .'</option>';
        } else {
	        $roles.= '<option>'. $users_role .'</option>';
        }
    }

    $sort_login = $orderby === 'user_login' ? 1 : 0;
    $sort_display_name = $orderby === 'display_name' ? 1 : 0;

    if ($orderby === 'user_login') {
	    $sort_icon_login = $order === 'asc' ? 'desc' : 'asc';
	    $sort_icon_display_name = 'desc';
    } else {
	    $sort_icon_display_name = $order === 'asc' ? 'desc' : 'asc';
	    $sort_icon_login = 'desc';
    }


	echo '
		<table class="custom-table">
		  <caption>Awesome clean table design</caption>
		  <tr>
		    <th>
		        <div>
                    User name 
                    <div
                        id="user_login"
                        class="sort-icon sort-icon-'. $sort_icon_login .'"
                        data-order="'. $sort_icon_login .'"
                        data-icon-active="'. $sort_login .'"
                    ></div>
		        </div>
		    </th>
		    <th>
                <div>
                    Display name
                    <div
                        id="display_name"
                        class="sort-icon sort-icon-'. $sort_icon_display_name .'"
                        data-order="'. $sort_icon_display_name .'"
                        data-icon-active="'. $sort_display_name .'"
                    ></div>
                </div>
		    </th>
		    <th>User Email</th>
		    <th>
		        <div>
                    User role
                    <select id="filter-role">
                      '. $roles .'
                    </select>
                </div>
		    </th>
		    <th>User registered</th>
		  </tr>
		  '. $result .'
		</table>
	';

?>

<div class="pagination">
	<?php

	// Previous page
	if ( $current_page > 1 ) {
		$prev_page = $current_page - 1;
		echo '<a id="prev-page" href="?page=' . $prev_page .'">Previous Page</a>';
	} else {
		echo '<a class="unactive" id="prev-page" href="#">Previous Page</a>';
	}

	for($i = 1; $i <= $num_pages; $i++) {
		if ( $i == $current_page ) {
			echo "<a class='active' href='?page={$i}'>{$i}</a>";
		}
		else echo "<a href='?page={$i}'>{$i}</a>";
	}

    // Next page
	if ( $current_page < $num_pages ) {
	    $next_page = $current_page + 1;
		echo '<a id="next-page" href="?page=' . $next_page .'">Next Page</a>';
	} else {
		echo '<a class="unactive" id="next-page" href="#">Next Page</a>';
	}
	?>
</div>
	<?php
}
