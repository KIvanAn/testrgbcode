jQuery(function($){
    jQuery('body').on('click', '#table .pagination a', function(e) {
        e.preventDefault();
        const page = jQuery(e.target).attr('href').slice(-1)
        const role = jQuery('#filter-role').val() === 'All roles' ? '' : jQuery('#filter-role').val()
        const orderby = jQuery('[data-icon-active="1"]').attr('id')
        const order = jQuery('[data-icon-active="1"]').data().order === 'asc' ? 'desc' : 'asc'
        const data = {
            action: 'new_page',
            nonce_code: myajax.nonce,
            page,
            role,
            orderby,
            order
        }
        jQuery.ajax({
            url: myajax.url,
            type: "POST",
            data
        }).done(function (res) {
            jQuery("#table").html(res)
        });
    });

    jQuery('body').on('change', '#filter-role', function(e) {
        const page = 1
        const role = e.target.value === 'All roles' ? '' : e.target.value
        const orderby = jQuery('[data-icon-active="1"]').attr('id')
        const order = jQuery('[data-icon-active="1"]').data().order === 'asc' ? 'desc' : 'asc'
        const data = {
            action: 'new_page',
            nonce_code: myajax.nonce,
            page,
            role,
            orderby,
            order
        }
        jQuery.ajax({
            url: myajax.url,
            type: "POST",
            data
        }).done(function (res) {
            jQuery("#table").html(res)
        });
    });

    jQuery('body').on('click', '#table .sort-icon', function(e) {
        const page = 1
        const role = jQuery('#filter-role').val() === 'All roles' ? '' : jQuery('#filter-role').val()
        const orderby = e.target.id
        const order = e.target.dataset.order
        const data = {
            action: 'new_page',
            nonce_code: myajax.nonce,
            page,
            role,
            orderby,
            order
        }
        jQuery.ajax({
            url: myajax.url,
            type: "POST",
            data
        }).done(function (res) {
            jQuery("#table").html(res)
        });
    });
});